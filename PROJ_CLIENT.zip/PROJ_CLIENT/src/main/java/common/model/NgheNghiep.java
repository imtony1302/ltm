package common.model;

import java.io.Serializable;

public class NgheNghiep implements Serializable
{

	private static final long serialVersionUID = 4082599461841946690L;

	private Integer ma;

	private String ten;

	private LoaiNgheNghiep loaiNgheNghiep;

	private String moTa;

	public NgheNghiep()
	{
		super();
	}

	public NgheNghiep(Integer ma, String ten, LoaiNgheNghiep loaiNgheNghiep, String moTa)
	{
		super();
		this.ma = ma;
		this.ten = ten;
		this.moTa = moTa;
		this.loaiNgheNghiep = loaiNgheNghiep;
	}

	public Integer getMa()
	{
		return ma;
	}

	public void setMa(Integer ma)
	{
		this.ma = ma;
	}

	public String getTen()
	{
		return ten;
	}

	public void setTen(String ten)
	{
		this.ten = ten;
	}

	public String getMoTa()
	{
		return moTa;
	}

	public void setMoTa(String moTa)
	{
		this.moTa = moTa;
	}

	public LoaiNgheNghiep getLoaiNgheNghiep()
	{
		return loaiNgheNghiep;
	}

	public void setLoaiNgheNghiep(LoaiNgheNghiep loaiNgheNghiep)
	{
		this.loaiNgheNghiep = loaiNgheNghiep;
	}


	@Override
	public String toString() {
		return "NgheNghiep{" +
				"ma=" + ma +
				", ten='" + ten + '\'' +
				'}';
	}
}
