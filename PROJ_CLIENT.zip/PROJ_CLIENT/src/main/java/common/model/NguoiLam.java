package common.model;

import java.io.Serializable;

public class NguoiLam implements Serializable
{

	private static final long serialVersionUID = -1415964282028259520L;

	private Integer ma;

	private String ten;

	private Integer namSinh;

	private String queQuan;

	private String gioiTinh;

	private NgheNghiep ngheNghiep;

	public NguoiLam()
	{
		super();
	}

	public NguoiLam(Integer ma, String ten, Integer namSinh, String queQuan, String gioiTinh, NgheNghiep ngheNghiep)
	{
		super();
		this.ma = ma;
		this.ten = ten;
		this.namSinh = namSinh;
		this.queQuan = queQuan;
		this.gioiTinh = gioiTinh;
		this.ngheNghiep = ngheNghiep;
	}

	public Integer getMa()
	{
		return ma;
	}

	public void setMa(Integer ma)
	{
		this.ma = ma;
	}

	public String getTen()
	{
		return ten;
	}

	public void setTen(String ten)
	{
		this.ten = ten;
	}

	public Integer getNamSinh()
	{
		return namSinh;
	}

	public void setNamSinh(Integer namSinh)
	{
		this.namSinh = namSinh;
	}

	public String getQueQuan()
	{
		return queQuan;
	}

	public void setQueQuan(String queQuan)
	{
		this.queQuan = queQuan;
	}

	public String getGioiTinh()
	{
		return gioiTinh;
	}

	public void setGioiTinh(String gioiTinh)
	{
		this.gioiTinh = gioiTinh;
	}


	public void setNgheNghiep(NgheNghiep ngheNghiep) {
		this.ngheNghiep = ngheNghiep;
	}

	public NgheNghiep getNgheNghiep() {
		return ngheNghiep;
	}
}
