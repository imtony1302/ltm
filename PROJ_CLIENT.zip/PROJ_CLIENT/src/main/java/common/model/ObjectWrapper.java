package common.model;

import java.io.Serializable;

public class ObjectWrapper implements Serializable
{

	private static final long serialVersionUID = 4_097_653_374_973_158_561L;
	public static final int THEM_LOAI_NGHE_NGHIEP = 1;
	public static final int SUA_LOAI_NGHE_NGHIEP = 2;
	public static final int XOA_LOAI_NGHE_NGHIEP = 3;
	public static final int THEM_TEN_NGHE_NGHIEP = 4;
	public static final int SUA_TEN_NGHE_NGHIEP = 5;
	public static final int XOA_TEN_NGHE_NGHIEP = 6;
	public static final int THEM_NGUOI_LAM = 7;
	public static final int SUA_NGUOI_LAM = 8;
	public static final int XOA_NGUOI_LAM = 9;

	public static final int REPLY_THEM_LOAI_NGHE_NGHIEP = 10;
	public static final int REPLY_SUA_LOAI_NGHE_NGHIEP = 11;
	public static final int REPLY_XOA_LOAI_NGHE_NGHIEP = 12;
	public static final int REPLY_THEM_TEN_NGHE_NGHIEP = 13;
	public static final int REPLY_SUA_TEN_NGHE_NGHIEP = 14;
	public static final int REPLY_XOA_TEN_NGHE_NGHIEP = 15;
	public static final int REPLY_THEM_NGUOI_LAM = 16;
	public static final int REPLY_SUA_NGUOI_LAM = 17;
	public static final int REPLY_XOA_NGUOI_LAM = 18;

	public static final int GET_ALL_LOAI_NGHE_NGHIEP = 19;

	public static final int GET_ALL_TEN_NGHE_NGHIEP = 20;

	public static final int GET_ALL_NGUOI_LAM = 21;

	public static final int REPLY_GET_ALL_LOAI_NGHE_NGHIEP = 22;

	public static final int REPLY_GET_ALL_TEN_NGHE_NGHIEP = 23;

	public static final int REPLY_GET_ALL_NGUOI_LAM = 24;

	private int performative;

	private Object data;

	public ObjectWrapper()
	{
		super();
	}

	public ObjectWrapper(int performative, Object data)
	{
		super();
		this.performative = performative;
		this.data = data;
	}

	public int getPerformative()
	{
		return performative;
	}

	public void setPerformative(int performative)
	{
		this.performative = performative;
	}

	public Object getData()
	{
		return data;
	}

	public void setData(Object data)
	{
		this.data = data;
	}

}
