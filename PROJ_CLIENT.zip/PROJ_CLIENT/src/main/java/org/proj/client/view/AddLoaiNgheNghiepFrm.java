package org.proj.client.view;

import common.model.LoaiNgheNghiep;
import common.model.ObjectWrapper;
import org.proj.client.controller.ClientCtr;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class AddLoaiNgheNghiepFrm extends JFrame implements ActionListener
{
	private LoaiNgheNghiep loaiNgheNghiep;
	private JTextField txtTen, txtMoTa;
	private JButton btnUpdate;
	private ClientCtr mySocket;

	private final  LoaiNgheNghiepFrm loaiNgheNghiepFrm;

	public AddLoaiNgheNghiepFrm(ClientCtr socket, LoaiNgheNghiep loaiNgheNghiep, LoaiNgheNghiepFrm loaiNgheNghiepFrm)
	{
		super("Thêm / sửa loại nghề nghiệp");
		this.loaiNgheNghiepFrm = loaiNgheNghiepFrm;
		mySocket = socket;
		this.loaiNgheNghiep = loaiNgheNghiep;

		JPanel pnMain = new JPanel();
		pnMain.setSize(this.getSize().width - 5, this.getSize().height - 20);
		pnMain.setLayout(new BoxLayout(pnMain, BoxLayout.Y_AXIS));
		pnMain.add(Box.createRigidArea(new Dimension(0, 10)));

		JLabel lblHome = new JLabel("Thêm / sửa loại nghề nghiệp");
		lblHome.setAlignmentX(Component.CENTER_ALIGNMENT);
		lblHome.setFont(lblHome.getFont().deriveFont(20.0f));
		pnMain.add(lblHome);
		pnMain.add(Box.createRigidArea(new Dimension(0, 20)));

		txtTen = new JTextField(15);
		txtMoTa = new JTextField(15);
		btnUpdate = new JButton("Create / Update");

		JPanel content = new JPanel();
		content.setLayout(new GridLayout(8, 2));
		content.add(new JLabel("Tên:"));
		content.add(txtTen);
		content.add(new JLabel("Mô tả:"));
		content.add(txtMoTa);
		content.add(btnUpdate);
		pnMain.add(content);
		btnUpdate.addActionListener(this);

		initForm();
		this.setContentPane(pnMain);
		this.setSize(600, 300);
		this.setLocation(200, 10);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}

	private void initForm()
	{
		if (loaiNgheNghiep != null)
		{
			txtTen.setText(loaiNgheNghiep.getTen() + "");
			txtMoTa.setText(loaiNgheNghiep.getMoTa());
		}
	}

	@Override
	public void actionPerformed(ActionEvent e)
	{
		// TODO Auto-generated method stub
		JButton btnClicked = (JButton) e.getSource();
		if (btnClicked.equals(btnUpdate))
		{

			boolean isAdd = loaiNgheNghiep == null;
			if (isAdd)
			{
				loaiNgheNghiep = new LoaiNgheNghiep();
			}

			loaiNgheNghiep.setTen(txtTen.getText());
			loaiNgheNghiep.setMoTa(txtMoTa.getText());

			// send data to the server
			if (isAdd)
			{
				mySocket.sendData(new ObjectWrapper(ObjectWrapper.THEM_LOAI_NGHE_NGHIEP, loaiNgheNghiep));
				ObjectWrapper data = mySocket.receiveData();
				if (data.getPerformative() == ObjectWrapper.REPLY_THEM_LOAI_NGHE_NGHIEP)
				{
					String result = (String) data.getData();
					if (result.equals("ok"))
					{
						JOptionPane.showMessageDialog(this, "Create succesfully!");
						loaiNgheNghiepFrm.updateTable();
						this.dispose();
					}
					else
					{
						JOptionPane.showMessageDialog(this, "Error when updating!");
					}
				}
			}
			else
			{
				mySocket.sendData(new ObjectWrapper(ObjectWrapper.SUA_LOAI_NGHE_NGHIEP, loaiNgheNghiep));
				ObjectWrapper data = mySocket.receiveData();
				if (data.getPerformative() == ObjectWrapper.REPLY_SUA_LOAI_NGHE_NGHIEP)
				{
					String result = (String) data.getData();
					if (result.equals("ok"))
					{
						JOptionPane.showMessageDialog(this, "Update succesfully!");
						loaiNgheNghiepFrm.updateTable();
						this.dispose();
					}
					else
					{
						JOptionPane.showMessageDialog(this, "Error when updating!");
					}
				}
			}
		}
	}
}