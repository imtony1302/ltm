package org.proj.client.view;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.*;

import common.model.NgheNghiep;
import org.proj.client.controller.ClientCtr;

import common.model.LoaiNgheNghiep;
import common.model.ObjectWrapper;

public class AddNgheNghiepFrm extends JFrame implements ActionListener
{
	private NgheNghiep ngheNghiep;
	private JTextField txtTen, txtMoTa;
	private JButton btnUpdate;

	private JComboBox<LoaiNgheNghiep> loaiNgheNghiepJComboBox;

	private ClientCtr mySocket;

	private final  NgheNghiepFrm ngheNghiepFrm;

	public AddNgheNghiepFrm(ClientCtr socket, NgheNghiep ngheNghiep, NgheNghiepFrm ngheNghiepFrm)
	{
		super("Thêm / sửa nghề nghiệp");
		this.ngheNghiepFrm = ngheNghiepFrm;
		mySocket = socket;
		this.ngheNghiep = ngheNghiep;

		JPanel pnMain = new JPanel();
		pnMain.setSize(this.getSize().width - 5, this.getSize().height - 20);
		pnMain.setLayout(new BoxLayout(pnMain, BoxLayout.Y_AXIS));
		pnMain.add(Box.createRigidArea(new Dimension(0, 10)));

		JLabel lblHome = new JLabel("Thêm / sửa nghề nghiệp");
		lblHome.setAlignmentX(Component.CENTER_ALIGNMENT);
		lblHome.setFont(lblHome.getFont().deriveFont(20.0f));
		pnMain.add(lblHome);
		pnMain.add(Box.createRigidArea(new Dimension(0, 20)));

		txtTen = new JTextField(15);
		txtMoTa = new JTextField(15);
		loaiNgheNghiepJComboBox = new JComboBox<>();
		mySocket.sendData(new ObjectWrapper(ObjectWrapper.GET_ALL_LOAI_NGHE_NGHIEP, null));
		ObjectWrapper data = mySocket.receiveData();
		if (data.getPerformative() == ObjectWrapper.REPLY_GET_ALL_LOAI_NGHE_NGHIEP) {
			List<LoaiNgheNghiep> listLoaiNgheNghiep = (ArrayList<LoaiNgheNghiep>) data.getData();
			for(LoaiNgheNghiep l: listLoaiNgheNghiep) {
				loaiNgheNghiepJComboBox.addItem(l);
			}
		}
		btnUpdate = new JButton("Create / Update");

		JPanel content = new JPanel();
		content.setLayout(new GridLayout(8, 2));
		content.add(new JLabel("Tên:"));
		content.add(txtTen);
		content.add(new JLabel("Mô tả:"));
		content.add(txtMoTa);
		content.add(new JLabel("Loại nghề nghiệp:"));
		content.add(loaiNgheNghiepJComboBox);
		content.add(btnUpdate);
		pnMain.add(content);
		btnUpdate.addActionListener(this);

		initForm();
		this.setContentPane(pnMain);
		this.setSize(600, 300);
		this.setLocation(200, 10);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}

	private void initForm()
	{
		if (ngheNghiep != null)
		{
			txtTen.setText(ngheNghiep.getTen() + "");
			txtMoTa.setText(ngheNghiep.getMoTa());
			mySocket.sendData(new ObjectWrapper(ObjectWrapper.GET_ALL_LOAI_NGHE_NGHIEP, null));
			ObjectWrapper data = mySocket.receiveData();
			if (data.getPerformative() == ObjectWrapper.REPLY_GET_ALL_LOAI_NGHE_NGHIEP) {
				List<LoaiNgheNghiep> listLoaiNgheNghiep = (ArrayList<LoaiNgheNghiep>) data.getData();
				for(int i = 0; i < listLoaiNgheNghiep.size(); i++) {
					if(listLoaiNgheNghiep.get(i).getMa().equals(ngheNghiep.getLoaiNgheNghiep().getMa())) {
						loaiNgheNghiepJComboBox.setSelectedIndex(i);
						break;
					}
				}
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e)
	{
		// TODO Auto-generated method stub
		JButton btnClicked = (JButton) e.getSource();
		if (btnClicked.equals(btnUpdate))
		{

			boolean isAdd = ngheNghiep == null;
			if (isAdd)
			{
				ngheNghiep = new NgheNghiep();
			}

			ngheNghiep.setTen(txtTen.getText());
			ngheNghiep.setMoTa(txtMoTa.getText());
			ngheNghiep.setLoaiNgheNghiep((LoaiNgheNghiep) loaiNgheNghiepJComboBox.getSelectedItem());

			// send data to the server
			if (isAdd)
			{
				mySocket.sendData(new ObjectWrapper(ObjectWrapper.THEM_TEN_NGHE_NGHIEP, ngheNghiep));
				ObjectWrapper data = mySocket.receiveData();
				if (data.getPerformative() == ObjectWrapper.REPLY_THEM_TEN_NGHE_NGHIEP)
				{
					String result = (String) data.getData();
					if (result.equals("ok"))
					{
						JOptionPane.showMessageDialog(this, "Create succesfully!");
						ngheNghiepFrm.updateTable();
						this.dispose();
					}
					else
					{
						JOptionPane.showMessageDialog(this, "Error when updating!");
					}
				}
			}
			else
			{
				mySocket.sendData(new ObjectWrapper(ObjectWrapper.SUA_TEN_NGHE_NGHIEP, ngheNghiep));
				ObjectWrapper data = mySocket.receiveData();
				if (data.getPerformative() == ObjectWrapper.REPLY_SUA_TEN_NGHE_NGHIEP)
				{
					String result = (String) data.getData();
					if (result.equals("ok"))
					{
						JOptionPane.showMessageDialog(this, "Update succesfully!");
						ngheNghiepFrm.updateTable();
						this.dispose();
					}
					else
					{
						JOptionPane.showMessageDialog(this, "Error when updating!");
					}
				}
			}
		}
	}
}