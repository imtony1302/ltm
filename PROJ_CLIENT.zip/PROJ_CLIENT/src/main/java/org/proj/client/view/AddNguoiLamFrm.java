package org.proj.client.view;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.*;

import common.model.NguoiLam;
import org.proj.client.controller.ClientCtr;

import common.model.LoaiNgheNghiep;
import common.model.NgheNghiep;
import common.model.ObjectWrapper;

public class AddNguoiLamFrm extends JFrame implements ActionListener
{
	private NguoiLam nguoiLam;
	private JTextField txtTen, txtNamSinh, txtQueQuan, txtGioiTinh;
	private JButton btnUpdate;

	private JComboBox<NgheNghiep> loaiNgheNghiepJComboBox;

	private ClientCtr mySocket;

	private final  NguoiLamFrm nguoiLamFrm;

	public AddNguoiLamFrm(ClientCtr socket, NguoiLam nguoiLam, NguoiLamFrm nguoiLamFrm)
	{
		super("Thêm / sửa Người Làm");
		this.nguoiLamFrm = nguoiLamFrm;
		mySocket = socket;
		this.nguoiLam = nguoiLam;

		JPanel pnMain = new JPanel();
		pnMain.setSize(this.getSize().width - 5, this.getSize().height - 20);
		pnMain.setLayout(new BoxLayout(pnMain, BoxLayout.Y_AXIS));
		pnMain.add(Box.createRigidArea(new Dimension(0, 10)));

		JLabel lblHome = new JLabel("Thêm / sửa Người Làm");
		lblHome.setAlignmentX(Component.CENTER_ALIGNMENT);
		lblHome.setFont(lblHome.getFont().deriveFont(20.0f));
		pnMain.add(lblHome);
		pnMain.add(Box.createRigidArea(new Dimension(0, 20)));

		txtTen = new JTextField(15);
		txtNamSinh = new JTextField(15);
		txtQueQuan = new JTextField(15);
		txtGioiTinh = new JTextField(15);

		loaiNgheNghiepJComboBox = new JComboBox<>();
		mySocket.sendData(new ObjectWrapper(ObjectWrapper.GET_ALL_TEN_NGHE_NGHIEP, null));
		ObjectWrapper data = mySocket.receiveData();
		if (data.getPerformative() == ObjectWrapper.REPLY_GET_ALL_TEN_NGHE_NGHIEP) {
			List<NgheNghiep> listNgheNghiep = (ArrayList<NgheNghiep>) data.getData();
			for(NgheNghiep l: listNgheNghiep) {
				loaiNgheNghiepJComboBox.addItem(l);
			}
		}
		btnUpdate = new JButton("Create / Update");

		JPanel content = new JPanel();
		content.setLayout(new GridLayout(8, 2));
		content.add(new JLabel("Tên:"));
		content.add(txtTen);
		content.add(new JLabel("Năm sinh:"));
		content.add(txtNamSinh);
		content.add(new JLabel("Quê quán:"));
		content.add(txtQueQuan);
		content.add(new JLabel("Giới tính:"));
		content.add(txtGioiTinh);
		content.add(new JLabel("Nghề nghiệp:"));
		content.add(loaiNgheNghiepJComboBox);
		content.add(new JLabel(""));
		content.add(btnUpdate);
		pnMain.add(content);
		btnUpdate.addActionListener(this);

		initForm();
		this.setContentPane(pnMain);
		this.setSize(600, 300);
		this.setLocation(200, 10);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}

	private void initForm()
	{
		if (nguoiLam != null)
		{
			txtTen.setText(nguoiLam.getTen() + "");
			txtNamSinh.setText(nguoiLam.getNamSinh() + "");
			txtQueQuan.setText(nguoiLam.getQueQuan());
			txtGioiTinh.setText(nguoiLam.getGioiTinh());
			mySocket.sendData(new ObjectWrapper(ObjectWrapper.GET_ALL_TEN_NGHE_NGHIEP, null));
			ObjectWrapper data = mySocket.receiveData();
			if (data.getPerformative() == ObjectWrapper.REPLY_GET_ALL_TEN_NGHE_NGHIEP) {
				List<NgheNghiep> listNgheNghiep = (ArrayList<NgheNghiep>) data.getData();
				for(int i = 0; i < listNgheNghiep.size(); i++) {
					if(listNgheNghiep.get(i).getMa().equals(nguoiLam.getNgheNghiep().getMa())) {
						loaiNgheNghiepJComboBox.setSelectedIndex(i);
						break;
					}
				}
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e)
	{
		// TODO Auto-generated method stub
		JButton btnClicked = (JButton) e.getSource();
		if (btnClicked.equals(btnUpdate))
		{

			boolean isAdd = nguoiLam == null;
			if (isAdd)
			{
				nguoiLam = new NguoiLam();
			}

			nguoiLam.setTen(txtTen.getText());
			nguoiLam.setNamSinh(Integer.parseInt(txtNamSinh.getText()));
			nguoiLam.setQueQuan(txtQueQuan.getText());
			nguoiLam.setGioiTinh(txtGioiTinh.getText());
			nguoiLam.setNgheNghiep((NgheNghiep) loaiNgheNghiepJComboBox.getSelectedItem());

			// send data to the server
			if (isAdd)
			{
				mySocket.sendData(new ObjectWrapper(ObjectWrapper.THEM_NGUOI_LAM, nguoiLam));
				ObjectWrapper data = mySocket.receiveData();
				if (data.getPerformative() == ObjectWrapper.REPLY_THEM_NGUOI_LAM)
				{
					String result = (String) data.getData();
					if (result.equals("ok"))
					{
						JOptionPane.showMessageDialog(this, "Create succesfully!");
						nguoiLamFrm.updateTable();
						this.dispose();
					}
					else
					{
						JOptionPane.showMessageDialog(this, "Error when updating!");
					}
				}
			}
			else
			{
				mySocket.sendData(new ObjectWrapper(ObjectWrapper.SUA_NGUOI_LAM, nguoiLam));
				ObjectWrapper data = mySocket.receiveData();
				if (data.getPerformative() == ObjectWrapper.REPLY_SUA_NGUOI_LAM)
				{
					String result = (String) data.getData();
					if (result.equals("ok"))
					{
						JOptionPane.showMessageDialog(this, "Update succesfully!");
						nguoiLamFrm.updateTable();
						this.dispose();
					}
					else
					{
						JOptionPane.showMessageDialog(this, "Error when updating!");
					}
				}
			}
		}
	}
}