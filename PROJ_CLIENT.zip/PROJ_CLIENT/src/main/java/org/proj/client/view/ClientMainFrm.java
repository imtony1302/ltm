package org.proj.client.view;

import org.proj.client.controller.ClientCtr;
import common.model.IPAddress;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class ClientMainFrm extends JFrame implements ActionListener
{
	private final JMenuBar mnbMain;
	private final JMenu mnClient;
	private final JMenuItem mniNguoiLam;

	private final JMenuItem mniNgheNghiep;

	private final JMenuItem mniLoaiNgheNghiep;

	private final JTextField txtServerHost;
	private final JTextField txtServerPort;
	private final JTextField txtClientHost;
	private final JTextField txtClientPort;
	private final JButton btnStart;
	private final JButton btnStop;
	private final JTextArea mainText;
	private ClientCtr myControl;

	public ClientMainFrm()
	{
		super("UDP client view");

		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(null);

		mnbMain = new JMenuBar();

		mnClient = new JMenu("Menu");

		mniNguoiLam = new JMenuItem("Người làm");
		mniNguoiLam.addActionListener(this);
		mnClient.add(mniNguoiLam);

		mniNgheNghiep = new JMenuItem("Nghề nghiệp");
		mniNgheNghiep.addActionListener(this);
		mnClient.add(mniNgheNghiep);

		mniLoaiNgheNghiep = new JMenuItem("Loại nghề nghiệp");
		mniLoaiNgheNghiep.addActionListener(this);
		mnClient.add(mniLoaiNgheNghiep);

		mnbMain.add(mnClient);
		this.setJMenuBar(mnbMain);

		mniNguoiLam.setEnabled(false);
		mniNgheNghiep.setEnabled(false);
		mniLoaiNgheNghiep.setEnabled(false);

		JLabel lblTitle = new JLabel("Client UDP");
		lblTitle.setFont(new java.awt.Font("Dialog", 1, 20));
		lblTitle.setBounds(new Rectangle(150, 20, 200, 30));
		mainPanel.add(lblTitle, null);

		JLabel lblHost = new JLabel("Server host:");
		lblHost.setBounds(new Rectangle(10, 70, 150, 25));
		mainPanel.add(lblHost, null);

		txtServerHost = new JTextField(50);
		txtServerHost.setBounds(new Rectangle(100, 70, 150, 25));
		mainPanel.add(txtServerHost, null);

		JLabel lblPort = new JLabel("Server port:");
		lblPort.setBounds(new Rectangle(10, 100, 150, 25));
		mainPanel.add(lblPort, null);

		txtServerPort = new JTextField(50);
		txtServerPort.setBounds(new Rectangle(100, 100, 150, 25));
		mainPanel.add(txtServerPort, null);

		JLabel lblClientHost = new JLabel("This client host:");
		lblClientHost.setBounds(new Rectangle(300, 70, 150, 25));
		mainPanel.add(lblClientHost, null);

		txtClientHost = new JTextField(50);
		txtClientHost.setText("localhost");
		txtClientHost.setBounds(new Rectangle(420, 70, 150, 25));
		txtClientHost.setEditable(false);
		mainPanel.add(txtClientHost, null);

		JLabel lblClientPort = new JLabel("This client port:");
		lblClientPort.setBounds(new Rectangle(300, 100, 150, 25));
		mainPanel.add(lblClientPort, null);

		txtClientPort = new JTextField(50);
		txtClientPort.setBounds(new Rectangle(420, 100, 150, 25));
		mainPanel.add(txtClientPort, null);

		btnStart = new JButton("Start");
		btnStart.setBounds(new Rectangle(10, 150, 150, 25));
		btnStart.addActionListener(this);
		mainPanel.add(btnStart, null);

		btnStop = new JButton("Stop");
		btnStop.setBounds(new Rectangle(170, 150, 150, 25));
		btnStop.addActionListener(this);
		btnStop.setEnabled(false);
		mainPanel.add(btnStop, null);

		JScrollPane jScrollPane1 = new JScrollPane();
		mainText = new JTextArea("");
		jScrollPane1.setBounds(new Rectangle(10, 200, 610, 240));
		mainPanel.add(jScrollPane1, BorderLayout.CENTER);
		jScrollPane1.getViewport().add(mainText, null);

		this.setContentPane(mainPanel);
		this.pack();
		this.setSize(new Dimension(640, 480));
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e)
			{
				if (myControl != null)
				{
					myControl.close();
				}
				System.exit(0);
			}
		});
	}

	public static void main(String[] args)
	{
		ClientMainFrm view = new ClientMainFrm();
		view.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent ae)
	{
		// TODO Auto-generated method stub
		if (ae.getSource() instanceof JButton)
		{
			JButton btn = (JButton) ae.getSource();
			if (btn.equals(btnStart))
			{// connect button
				if (!txtServerHost.getText().isEmpty() && (txtServerHost.getText().trim().length() > 0) &&
					!txtServerPort.getText().isEmpty() && (txtServerPort.getText().trim().length() > 0))
				{// custom server port
					int serverPort = Integer.parseInt(txtServerPort.getText().trim());
					if (!txtClientPort.getText().isEmpty() && (txtClientPort.getText().trim().length() > 0))
					{// custom client port
						int clientPort = Integer.parseInt(txtClientPort.getText().trim());
						myControl = new ClientCtr(this, new IPAddress(txtServerHost.getText().trim(), serverPort),
							clientPort);
					}
					else
					{// default client port
						myControl = new ClientCtr(this, new IPAddress(txtServerHost.getText().trim(), serverPort));
					}
				}
				else
				{// default server host and port
					if (!txtClientPort.getText().isEmpty() && (txtClientPort.getText().trim().length() > 0))
					{// custom client port
						int clientPort = Integer.parseInt(txtClientPort.getText().trim());
						myControl = new ClientCtr(this, clientPort);
					}
					else
					{// default client port
						myControl = new ClientCtr(this);
					}
				}

				if (myControl.open())
				{
					btnStop.setEnabled(true);
					btnStart.setEnabled(false);
					mniNguoiLam.setEnabled(true);
					mniLoaiNgheNghiep.setEnabled(true);
					mniNgheNghiep.setEnabled(true);
				}
				else
				{
					if (myControl != null)
					{
						myControl.close();
						myControl = null;
					}
					btnStop.setEnabled(false);
					btnStart.setEnabled(true);
					mniNguoiLam.setEnabled(false);
					mniNgheNghiep.setEnabled(false);
					mniLoaiNgheNghiep.setEnabled(false);
				}
			}
			else if (btn.equals(btnStop))
			{// disconnect button
				if (myControl != null)
				{
					myControl.close();
					myControl = null;
				}
				btnStop.setEnabled(false);
				btnStart.setEnabled(true);
				mniNguoiLam.setEnabled(false);
				mniNgheNghiep.setEnabled(false);
				mniLoaiNgheNghiep.setEnabled(false);
			}
		}
		else if (ae.getSource() instanceof JMenuItem)
		{
			JMenuItem mni = (JMenuItem) ae.getSource();
			if (mni.equals(mniNguoiLam))
			{
				NguoiLamFrm nguoiLamFrm = new NguoiLamFrm(myControl);
				nguoiLamFrm.setVisible(true);
			}
			else if (mni.equals(mniLoaiNgheNghiep))
			{
				LoaiNgheNghiepFrm loaiNgheNghiepFrm = new LoaiNgheNghiepFrm(myControl);
				loaiNgheNghiepFrm.setVisible(true);
			}
			else if (mni.equals(mniNgheNghiep))
			{
				NgheNghiepFrm ngheNghiepFrm = new NgheNghiepFrm(myControl);
				ngheNghiepFrm.setVisible(true);
			}
		}
	}

	public void showMessage(String s)
	{
		mainText.append("\n" + s);
		mainText.setCaretPosition(mainText.getDocument().getLength());
	}

	public void setServerandClientInfo(IPAddress serverAddress, IPAddress clientAddress)
	{
		txtServerHost.setText(serverAddress.getHost());
		txtServerPort.setText(String.valueOf(serverAddress.getPort()));
		txtClientHost.setText(clientAddress.getHost());
		txtClientPort.setText(String.valueOf(clientAddress.getPort()));
	}
}