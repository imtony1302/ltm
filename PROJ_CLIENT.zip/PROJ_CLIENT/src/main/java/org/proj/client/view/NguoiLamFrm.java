package org.proj.client.view;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Comparator;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import common.model.NguoiLam;
import org.proj.client.controller.ClientCtr;

import common.model.NgheNghiep;
import common.model.ObjectWrapper;

public class NguoiLamFrm extends JFrame implements ActionListener
{
	private ArrayList<NguoiLam> listNguoiLam;

	private final JButton addNewBtn;

	private final JButton editBtn;

	private final JButton deleteBtn;

	private final JTable tblResult;

	private final ClientCtr mySocket;

	public NguoiLamFrm(ClientCtr socket)
	{
		super("Người Làm");
		mySocket = socket;
		listNguoiLam = new ArrayList<>();

		JPanel pnMain = new JPanel();
		pnMain.setSize(this.getSize().width - 5, this.getSize().height - 20);
		pnMain.setLayout(new BoxLayout(pnMain, BoxLayout.Y_AXIS));
		pnMain.add(Box.createRigidArea(new Dimension(0, 10)));

		JLabel lblHome = new JLabel("Người Làm");
		lblHome.setAlignmentX(Component.CENTER_ALIGNMENT);
		lblHome.setFont(lblHome.getFont().deriveFont(20.0f));
		pnMain.add(lblHome);
		pnMain.add(Box.createRigidArea(new Dimension(0, 20)));

		JPanel pn1 = new JPanel();
		pn1.setLayout(new BoxLayout(pn1, BoxLayout.X_AXIS));
		pn1.setSize(this.getSize().width - 5, 20);

		addNewBtn = new JButton("Add");
		addNewBtn.setBounds(new Rectangle(10, 150, 150, 25));
		addNewBtn.addActionListener(this);
		pn1.add(addNewBtn, null);

		editBtn = new JButton("Edit");
		editBtn.setBounds(new Rectangle(10, 150, 150, 25));
		editBtn.addActionListener(this);
		pn1.add(editBtn, null);

		deleteBtn = new JButton("Delete");
		deleteBtn.setBounds(new Rectangle(10, 150, 150, 25));
		deleteBtn.addActionListener(this);
		pn1.add(deleteBtn, null);

		pnMain.add(pn1);
		pnMain.add(Box.createRigidArea(new Dimension(0, 10)));

		JPanel pn2 = new JPanel();
		pn2.setLayout(new BoxLayout(pn2, BoxLayout.Y_AXIS));
		tblResult = new JTable();
		JScrollPane scrollPane = new JScrollPane(tblResult);
		tblResult.setFillsViewportHeight(false);
		scrollPane.setPreferredSize(new Dimension(scrollPane.getPreferredSize().width, 250));

		updateTable();

		pn2.add(scrollPane);
		pnMain.add(pn2);
		this.add(pnMain);
		this.setSize(600, 300);
		this.setLocation(200, 10);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}

	public void updateTable()
	{
		// send data to the server
		mySocket.sendData(new ObjectWrapper(ObjectWrapper.GET_ALL_NGUOI_LAM, null));

		// receive result from the server
		ObjectWrapper data = mySocket.receiveData();
		if (data.getPerformative() == ObjectWrapper.REPLY_GET_ALL_NGUOI_LAM)
		{
			listNguoiLam = (ArrayList<NguoiLam>) data.getData();

			listNguoiLam.sort(Comparator.comparingInt(NguoiLam::getMa));

			String[] columnNames = { "Mã", "Tên", "Năm sinh", "Quê quán", "Giới tính", "Nghề nghiệp" };
			String[][] value = new String[listNguoiLam.size()][columnNames.length];
			for (int i = 0; i < listNguoiLam.size(); i++)
			{
				value[i][0] = String.valueOf(listNguoiLam.get(i).getMa());
				value[i][1] = listNguoiLam.get(i).getTen();
				value[i][2] = "" + listNguoiLam.get(i).getNamSinh();
				value[i][3] = listNguoiLam.get(i).getQueQuan();
				value[i][4] = listNguoiLam.get(i).getGioiTinh();
				value[i][5] = listNguoiLam.get(i).getNgheNghiep().getTen();
			}
			DefaultTableModel tableModel = new DefaultTableModel(value, columnNames) {
				@Override
				public boolean isCellEditable(int row, int column)
				{
					// unable to edit cells
					return false;
				}
			};
			tblResult.setModel(tableModel);
		}
	}

	@Override
	public void actionPerformed(ActionEvent e)
	{
		JButton btnClicked = (JButton) e.getSource();
		if (btnClicked.equals(deleteBtn))
		{
			int row = tblResult.getSelectedRow();
			if (row >= 0)
			{
				NguoiLam nguoiLam = this.listNguoiLam.get(row);
				mySocket.sendData(new ObjectWrapper(ObjectWrapper.XOA_NGUOI_LAM, nguoiLam));

				// receive result from the server
				ObjectWrapper data = mySocket.receiveData();
				if (data.getPerformative() == ObjectWrapper.REPLY_XOA_NGUOI_LAM)
				{
					this.updateTable();
				}
			}
		}
		else if (btnClicked.equals(addNewBtn))
		{
			new AddNguoiLamFrm(mySocket, null, this).setVisible(true);
		}
		else if (btnClicked.equals(editBtn))
		{
			int row = tblResult.getSelectedRow();
			if (row >= 0)
			{
				new AddNguoiLamFrm(mySocket, listNguoiLam.get(row), this).setVisible(true);
			}
		}
	}
}