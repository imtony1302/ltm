package com.proj.server.controller;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

import com.proj.server.dao.LoaiNgheNghiepDAO;
import com.proj.server.dao.NgheNghiepDAO;
import com.proj.server.dao.NguoiLamDAO;
import common.model.*;
import com.proj.server.view.ServerMainFrm;

public class ServerCtr
{
	private final ServerMainFrm view;
	private final IPAddress myAddress = new IPAddress("localhost", 5555); // default server address
	private DatagramSocket myServer;
	private UDPListening myListening;

	public ServerCtr(ServerMainFrm view)
	{
		this.view = view;
	}

	public ServerCtr(ServerMainFrm view, int port)
	{
		this.view = view;
		myAddress.setPort(port);
	}

	public boolean open()
	{
		try
		{
			myServer = new DatagramSocket(myAddress.getPort());
			myAddress.setHost(InetAddress.getLocalHost().getHostAddress());
			view.showServerInfo(myAddress);
			myListening = new UDPListening();
			myListening.start();
			view.showMessage(
				"UDP server is running at the host: " + myAddress.getHost() + ", port: " + myAddress.getPort());
		}
		catch (Exception e)
		{
			e.printStackTrace();
			view.showMessage("Error to open the datagram socket!");
			return false;
		}
		return true;
	}

	public boolean close()
	{
		try
		{
			myListening.stop();
			myServer.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			view.showMessage("Error to close the datagram socket!");
			return false;
		}
		return true;
	}

	class UDPListening extends Thread
	{
		public UDPListening()
		{

		}

		public void run()
		{
			while (true)
			{
				try
				{
					// prepare the buffer and fetch the received data into the buffer
					byte[] receiveData = new byte[1024];
					DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
					myServer.receive(receivePacket);

					// read incoming data from the buffer
					ByteArrayInputStream bais = new ByteArrayInputStream(receiveData);
					ObjectInputStream ois = new ObjectInputStream(bais);
					ObjectWrapper receivedData = (ObjectWrapper) ois.readObject();

					// processing
					ObjectWrapper resultData = new ObjectWrapper();
					LoaiNgheNghiep loaiNgheNghiep;
					NgheNghiep ngheNghiep;
					NguoiLam nguoiLam;
					switch (receivedData.getPerformative())
					{
					case ObjectWrapper.THEM_LOAI_NGHE_NGHIEP:
						loaiNgheNghiep = (LoaiNgheNghiep) receivedData.getData();
						resultData.setPerformative(ObjectWrapper.REPLY_THEM_LOAI_NGHE_NGHIEP);
						if (new LoaiNgheNghiepDAO().addNew(loaiNgheNghiep))
							resultData.setData("ok");
						else
							resultData.setData("false");
						break;
					case ObjectWrapper.SUA_LOAI_NGHE_NGHIEP:
						loaiNgheNghiep = (LoaiNgheNghiep) receivedData.getData();
						resultData.setPerformative(ObjectWrapper.REPLY_SUA_LOAI_NGHE_NGHIEP);
						if (new LoaiNgheNghiepDAO().edit(loaiNgheNghiep))
							resultData.setData("ok");
						else
							resultData.setData("false");
						break;
					case ObjectWrapper.XOA_LOAI_NGHE_NGHIEP:
						loaiNgheNghiep = (LoaiNgheNghiep) receivedData.getData();
						resultData.setPerformative(ObjectWrapper.REPLY_XOA_LOAI_NGHE_NGHIEP);
						if (new LoaiNgheNghiepDAO().remove(loaiNgheNghiep))
							resultData.setData("ok");
						else
							resultData.setData("false");
						break;
					case ObjectWrapper.THEM_TEN_NGHE_NGHIEP:
						ngheNghiep = (NgheNghiep) receivedData.getData();
						resultData.setPerformative(ObjectWrapper.REPLY_THEM_TEN_NGHE_NGHIEP);
						if (new NgheNghiepDAO().addNew(ngheNghiep))
							resultData.setData("ok");
						else
							resultData.setData("false");
						break;
					case ObjectWrapper.SUA_TEN_NGHE_NGHIEP:
						ngheNghiep = (NgheNghiep) receivedData.getData();
						resultData.setPerformative(ObjectWrapper.REPLY_SUA_TEN_NGHE_NGHIEP);
						if (new NgheNghiepDAO().edit(ngheNghiep))
							resultData.setData("ok");
						else
							resultData.setData("false");
						break;
					case ObjectWrapper.XOA_TEN_NGHE_NGHIEP:
						ngheNghiep = (NgheNghiep) receivedData.getData();
						resultData.setPerformative(ObjectWrapper.REPLY_XOA_TEN_NGHE_NGHIEP);
						if (new NgheNghiepDAO().remove(ngheNghiep))
							resultData.setData("ok");
						else
							resultData.setData("false");
						break;
					case ObjectWrapper.THEM_NGUOI_LAM:
						nguoiLam = (NguoiLam) receivedData.getData();
						resultData.setPerformative(ObjectWrapper.REPLY_THEM_NGUOI_LAM);
						if (new NguoiLamDAO().addNew(nguoiLam))
							resultData.setData("ok");
						else
							resultData.setData("false");
						break;
					case ObjectWrapper.SUA_NGUOI_LAM:
						nguoiLam = (NguoiLam) receivedData.getData();
						resultData.setPerformative(ObjectWrapper.REPLY_SUA_NGUOI_LAM);
						if (new NguoiLamDAO().edit(nguoiLam))
							resultData.setData("ok");
						else
							resultData.setData("false");
						break;
					case ObjectWrapper.XOA_NGUOI_LAM:
						nguoiLam = (NguoiLam) receivedData.getData();
						resultData.setPerformative(ObjectWrapper.REPLY_XOA_NGUOI_LAM);
						if (new NguoiLamDAO().remove(nguoiLam))
							resultData.setData("ok");
						else
							resultData.setData("false");
						break;
					case ObjectWrapper.GET_ALL_LOAI_NGHE_NGHIEP:
						resultData.setPerformative(ObjectWrapper.REPLY_GET_ALL_LOAI_NGHE_NGHIEP);
						resultData.setData(new LoaiNgheNghiepDAO().getAll());
						break;
					case ObjectWrapper.GET_ALL_TEN_NGHE_NGHIEP:
						resultData.setPerformative(ObjectWrapper.REPLY_GET_ALL_TEN_NGHE_NGHIEP);
						resultData.setData(new NgheNghiepDAO().getAll());
						break;
					case ObjectWrapper.GET_ALL_NGUOI_LAM:
						resultData.setPerformative(ObjectWrapper.REPLY_GET_ALL_NGUOI_LAM);
						resultData.setData(new NguoiLamDAO().getAll());
						break;
					}

					// prepare the buffer and write the data to send into the buffer
					ByteArrayOutputStream baos = new ByteArrayOutputStream();
					ObjectOutputStream oos = new ObjectOutputStream(baos);
					oos.writeObject(resultData);
					oos.flush();

					// create data package and send
					byte[] sendData = baos.toByteArray();
					DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length,
						receivePacket.getAddress(), receivePacket.getPort());
					myServer.send(sendPacket);
				}
				catch (Exception e)
				{
					e.printStackTrace();
					view.showMessage("Error when processing an incoming package");
				}
			}
		}
	}
}