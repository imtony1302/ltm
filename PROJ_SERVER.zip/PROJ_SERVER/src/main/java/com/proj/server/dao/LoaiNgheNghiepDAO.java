package com.proj.server.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import common.model.LoaiNgheNghiep;

public class LoaiNgheNghiepDAO extends DAO
{

	public ArrayList<LoaiNgheNghiep> getAll()
	{
		ArrayList<LoaiNgheNghiep> result = new ArrayList<LoaiNgheNghiep>();
		String sql = "SELECT * FROM LoaiNgheNghiep";
		try
		{
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();

			while (rs.next())
			{
				LoaiNgheNghiep loaiNgheNghiep = new LoaiNgheNghiep();
				loaiNgheNghiep.setMa(rs.getInt("ma"));
				loaiNgheNghiep.setTen(rs.getString("ten"));
				loaiNgheNghiep.setMoTa(rs.getString("moTa"));
				result.add(loaiNgheNghiep);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return result;
	}

	public LoaiNgheNghiep getById(Integer id)
	{
		LoaiNgheNghiep result = null;
		String sql = "SELECT * FROM LoaiNgheNghiep WHERE ma = ? ";
		try
		{
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();

			while (rs.next())
			{
				LoaiNgheNghiep loaiNgheNghiep = new LoaiNgheNghiep();
				loaiNgheNghiep.setMa(rs.getInt("ma"));
				loaiNgheNghiep.setTen(rs.getString("ten"));
				loaiNgheNghiep.setMoTa(rs.getString("moTa"));
				result = loaiNgheNghiep;
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return result;
	}

	public boolean addNew(LoaiNgheNghiep loaiNgheNghiep)
	{
		String sql = "INSERT INTO LoaiNgheNghiep (ten, moTa) VALUES (?, ?)";
		try
		{
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, loaiNgheNghiep.getTen());
			ps.setString(2, loaiNgheNghiep.getMoTa());
			ps.execute();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean edit(LoaiNgheNghiep loaiNgheNghiep)
	{
		String sql = "UPDATE LoaiNgheNghiep SET ten = ?, moTa =? WHERE ma = ?";
		try
		{
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, loaiNgheNghiep.getTen());
			ps.setString(2, loaiNgheNghiep.getMoTa());
			ps.setInt(3, loaiNgheNghiep.getMa());
			ps.executeUpdate();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean remove(LoaiNgheNghiep loaiNgheNghiep)
	{
		String sql = "DELETE FROM LoaiNgheNghiep WHERE ma = ?";
		try
		{
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, loaiNgheNghiep.getMa());
			ps.execute();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return false;
		}
		return true;
	}

}
