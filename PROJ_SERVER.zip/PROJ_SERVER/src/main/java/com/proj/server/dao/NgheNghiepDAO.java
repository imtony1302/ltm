package com.proj.server.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import common.model.LoaiNgheNghiep;
import common.model.NgheNghiep;

public class NgheNghiepDAO extends DAO
{

	public ArrayList<NgheNghiep> getAll()
	{
		ArrayList<NgheNghiep> result = new ArrayList<NgheNghiep>();
		String sql = "SELECT * FROM NgheNghiep";
		try
		{
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();

			while (rs.next())
			{
				NgheNghiep ngheNghiep = new NgheNghiep();
				ngheNghiep.setMa(rs.getInt("ma"));
				ngheNghiep.setTen(rs.getString("ten"));
				ngheNghiep.setMoTa(rs.getString("moTa"));
				ngheNghiep.setLoaiNgheNghiep((new LoaiNgheNghiepDAO().getById(rs.getInt("fk_loai_nghe_nghiep"))));
				result.add(ngheNghiep);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return result;
	}

	public boolean addNew(NgheNghiep ngheNghiep)
	{
		String sql = "INSERT INTO NgheNghiep (ten, moTa, fk_loai_nghe_nghiep) VALUES (?, ?, ?)";
		try
		{
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, ngheNghiep.getTen());
			ps.setString(2, ngheNghiep.getMoTa());
			ps.setInt(3, ngheNghiep.getLoaiNgheNghiep().getMa());
			ps.execute();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean edit(NgheNghiep ngheNghiep)
	{
		String sql = "UPDATE NgheNghiep SET ten = ?, moTa =?, fk_loai_nghe_nghiep = ? WHERE ma = ?";
		try
		{
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, ngheNghiep.getTen());
			ps.setString(2, ngheNghiep.getMoTa());
			ps.setInt(3, ngheNghiep.getLoaiNgheNghiep().getMa());
			ps.setInt(4, ngheNghiep.getMa());
			ps.executeUpdate();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean remove(NgheNghiep ngheNghiep)
	{
		String sql = "DELETE FROM NgheNghiep WHERE ma = ?";
		try
		{
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, ngheNghiep.getMa());
			ps.execute();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public NgheNghiep getById(Integer id)
	{
		NgheNghiep result = null;
		String sql = "SELECT * FROM NgheNghiep WHERE ma = ? ";
		try
		{
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();

			while (rs.next())
			{
				NgheNghiep ngheNghiep = new NgheNghiep();
				ngheNghiep.setMa(rs.getInt("ma"));
				ngheNghiep.setTen(rs.getString("ten"));
				ngheNghiep.setMoTa(rs.getString("moTa"));
				ngheNghiep.setLoaiNgheNghiep((new LoaiNgheNghiepDAO().getById(rs.getInt("fk_loai_nghe_nghiep"))));
				result = ngheNghiep;
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return result;
	}

}
