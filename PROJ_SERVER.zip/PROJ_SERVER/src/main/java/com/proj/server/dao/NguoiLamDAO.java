package com.proj.server.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import common.model.NgheNghiep;
import common.model.NguoiLam;

public class NguoiLamDAO extends DAO
{

	public ArrayList<NguoiLam> getAll()
	{
		ArrayList<NguoiLam> result = new ArrayList<NguoiLam>();
		String sql = "SELECT * FROM NguoiLam";
		try
		{
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();

			while (rs.next())
			{
				NguoiLam nguoiLam = new NguoiLam();
				nguoiLam.setMa(rs.getInt("ma"));
				nguoiLam.setTen(rs.getString("ten"));
				nguoiLam.setNamSinh(rs.getInt("namSinh"));
				nguoiLam.setQueQuan(rs.getString("queQuan"));
				nguoiLam.setGioiTinh(rs.getString("gioiTinh"));
				nguoiLam.setNgheNghiep((new NgheNghiepDAO().getById(rs.getInt("fk_nghe_nghiep"))));
				result.add(nguoiLam);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return result;
	}

	public boolean addNew(NguoiLam nguoiLam)
	{
		String sql = "INSERT INTO NguoiLam (ten, namSinh, queQuan, gioiTinh, fk_nghe_nghiep) VALUES (?, ?, ?, ?, ?)";
		try
		{
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, nguoiLam.getTen());
			ps.setInt(2, nguoiLam.getNamSinh());
			ps.setString(3, nguoiLam.getQueQuan());
			ps.setString(4, nguoiLam.getGioiTinh());
			ps.setInt(5, nguoiLam.getNgheNghiep().getMa());
			ps.execute();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean edit(NguoiLam nguoiLam)
	{
		String sql = "UPDATE NguoiLam SET ten = ?, namSinh =?, queQuan = ?, gioiTinh = ?, fk_nghe_nghiep = ? WHERE ma = ?";
		try
		{
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, nguoiLam.getTen());
			ps.setInt(2, nguoiLam.getNamSinh());
			ps.setString(3, nguoiLam.getQueQuan());
			ps.setString(4, nguoiLam.getGioiTinh());
			ps.setInt(5, nguoiLam.getNgheNghiep().getMa());
			ps.setInt(6, nguoiLam.getMa());
			ps.executeUpdate();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean remove(NguoiLam nguoiLam)
	{
		String sql = "DELETE FROM NguoiLam WHERE ma = ?";
		try
		{
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, nguoiLam.getMa());
			ps.execute();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return false;
		}
		return true;
	}

}
